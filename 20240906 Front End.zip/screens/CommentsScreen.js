import React, {useEffect, useState} from 'react';
import {View, Text, FlatList, StyleSheet} from 'react-native';
import {getComments} from '../api/api';

const CommentsScreen = ({route}) => {
  const {activityId, userId} = route.params;
  const [comments, setComments] = useState([]);

  useEffect(() => {
    const fetchComments = async () => {
      try {
        const comments = await getComments(userId, activityId);
        setComments(comments);
      } catch (error) {
        console.error('Failed to fetch comments:', error);
      }
    };

    fetchComments();
  }, [activityId, userId]);

  const renderComment = ({item}) => (
    <View style={styles.commentItem}>
      <Text style={styles.commentText}>{item.comment}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={comments}
        renderItem={renderComment}
        keyExtractor={item => item.id.toString()}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  // your styles here
});

export default CommentsScreen;
