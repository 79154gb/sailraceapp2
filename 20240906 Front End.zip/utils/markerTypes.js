const markerTypes = [
  {label: 'Start Mark 1', value: 'start1', color: 'blue'},
  {label: 'Start Mark 2', value: 'start2', color: 'cyan'},
  {label: 'Windward Mark', value: 'windward', color: 'red'},
  {label: 'Leeward Mark', value: 'leeward', color: 'green'},
  {label: 'Reach Mark', value: 'reach', color: 'yellow'},
];

export default markerTypes;
