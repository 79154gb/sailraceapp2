// Utility function to calculate VMG (Velocity Made Good)
function calculateVMG(windDirection, boatSpeed, boatHeading) {
  console.log('--- VMG Calculation ---');
  console.log(
    `Input - Wind Direction: ${windDirection}, Boat Speed: ${boatSpeed}, Boat Heading: ${boatHeading}`,
  );

  if (typeof windDirection !== 'number' || typeof boatSpeed !== 'number') {
    console.error(
      'Invalid input for VMG calculation. Wind direction or boat speed is undefined.',
    );
    return NaN;
  }

  const relativeWindAngle = (boatHeading - windDirection + 360) % 360;

  // Validate if the angle is valid for VMG calculation
  if (relativeWindAngle > 180) {
    console.log(
      `Output - VMG: NaN (No sailing possible at angle ${
        relativeWindAngle - 180
      })`,
    );
    return NaN;
  }

  const vmg = boatSpeed * Math.cos((relativeWindAngle * Math.PI) / 180);
  console.log(`Output - VMG: ${vmg}`);
  return vmg;
}

// Function to calculate optimal route given a start position, marks, wind, and tide data
function calculateOptimalRoute(
  startPosition,
  marks,
  windData,
  tideData,
  tackAssistance = false,
) {
  console.log('--- Optimal Route Calculation ---');
  console.log(
    `Input - Start Position: ${JSON.stringify(
      startPosition,
    )}, Marks: ${JSON.stringify(marks)}, Wind Data: ${JSON.stringify(
      windData,
    )}, Tide Data: ${JSON.stringify(
      tideData,
    )}, Tack Assistance: ${JSON.stringify(tackAssistance)}`,
  );

  // Validate tideData before using
  if (
    typeof tideData.speed !== 'number' ||
    typeof tideData.direction !== 'number'
  ) {
    console.error('Invalid tide data:', tideData);
    return [];
  }

  // Extract wind data from tideData
  let windSpeed = tideData.speed;
  let windDirection = tideData.direction;

  // Convert marks object to array if it's not already an array
  if (!Array.isArray(marks)) {
    marks = Object.values(marks);
  }

  const optimalRoute = [];
  let currentPosition = startPosition;

  marks.forEach((mark, index) => {
    // Validate mark data
    if (
      !mark ||
      typeof mark.latitude !== 'number' ||
      typeof mark.longitude !== 'number'
    ) {
      console.error(`Invalid mark data for mark ${index + 1}:`, mark);
      return;
    }

    console.log(
      `Calculating route to mark ${index + 1}: ${JSON.stringify(mark)}`,
    );

    const headingToMark = calculateHeading(currentPosition, mark);
    const distanceToMark = calculateDistance(currentPosition, mark);

    console.log(`Calculated Heading to Mark: ${headingToMark}`);
    console.log(`Calculated Distance to Mark: ${distanceToMark}`);

    if (isNaN(distanceToMark) || isNaN(headingToMark)) {
      console.error(
        'Error: Invalid calculation result - Heading or Distance is NaN.',
      );
      return;
    }

    let bestVMG = -Infinity;
    let bestHeading = headingToMark;
    let bestSpeed = 0;

    for (let angle = 0; angle <= 360; angle++) {
      const speed = getSpeedFromPolars(angle, windSpeed); // Function to get speed based on boat polars

      if (isNaN(speed)) {
        console.error('Invalid speed data.');
        continue;
      }

      const vmg = calculateVMG(windDirection, speed, angle);

      console.log(`Angle: ${angle}, Speed: ${speed}, VMG: ${vmg}`);

      if (vmg > bestVMG) {
        bestVMG = vmg;
        bestHeading = angle;
        bestSpeed = speed;
      }
    }

    if (bestVMG <= 0) {
      console.error('Error: No valid heading with positive VMG found.');
      return;
    }

    const timeToMark = distanceToMark / bestSpeed;
    console.log(
      `Optimal Heading: ${bestHeading}, Speed: ${bestSpeed}, Time to Mark: ${timeToMark}`,
    );

    optimalRoute.push({
      action: 'Sail',
      from: currentPosition,
      heading: bestHeading,
      speed: bestSpeed,
      time: timeToMark,
      to: mark,
    });

    currentPosition = mark; // Update position to the current mark

    // Additional logic for adding tacking waypoints if necessary
    if (needToTack(currentPosition, mark, windDirection)) {
      const intermediateWaypoint = calculateIntermediateWaypoint(
        currentPosition,
        mark,
        windDirection,
      );
      if (
        intermediateWaypoint.latitude !== null &&
        intermediateWaypoint.longitude !== null
      ) {
        optimalRoute.push({
          action: 'Tack',
          from: currentPosition,
          heading: bestHeading,
          speed: bestSpeed,
          time: timeToMark / 2,
          to: intermediateWaypoint,
        });
        console.log(
          `Adding intermediate waypoint for tacking: ${JSON.stringify(
            intermediateWaypoint,
          )}`,
        );
        currentPosition = intermediateWaypoint; // Update to intermediate waypoint
      } else {
        console.error(
          'Error: Failed to calculate a valid intermediate waypoint.',
        );
      }
    }
  });

  console.log('--- Optimal Route Result ---');
  console.log(JSON.stringify(optimalRoute));
  return optimalRoute;
}

// Function to calculate heading between two points
function calculateHeading(from, to) {
  console.log('--- Calculating Heading ---');
  console.log(`From: ${JSON.stringify(from)}, To: ${JSON.stringify(to)}`);

  const deltaY = to.latitude - from.latitude;
  const deltaX = to.longitude - from.longitude;
  const heading = Math.atan2(deltaY, deltaX) * (180 / Math.PI);

  console.log(`Output - Heading: ${heading}`);
  return heading;
}

// Function to calculate distance between two points using the Haversine formula
function calculateDistance(from, to) {
  console.log('--- Calculating Distance ---');
  console.log(`From: ${JSON.stringify(from)}, To: ${JSON.stringify(to)}`);

  const R = 6371e3; // Earth radius in meters
  const φ1 = (from.latitude * Math.PI) / 180;
  const φ2 = (to.latitude * Math.PI) / 180;
  const Δφ = ((to.latitude - from.latitude) * Math.PI) / 180;
  const Δλ = ((to.longitude - from.longitude) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  const distance = R * c; // Distance in meters

  console.log(`Output - Distance: ${distance}`);
  return distance;
}

// Example placeholder function to retrieve speed from polars
function getSpeedFromPolars(heading, windSpeed) {
  console.log('--- Get Speed from Polars ---');
  console.log(`Input - Heading: ${heading}, Wind Speed: ${windSpeed}`);

  if (typeof windSpeed !== 'number') {
    console.error('Invalid wind speed data.');
    return NaN;
  }

  // Simplified speed retrieval logic based on heading and wind speed
  const speed = Math.max(0, 10 - Math.abs(180 - heading) / 18); // Mock formula for speed calculation

  console.log(`Output - Speed: ${speed}`);
  return speed;
}

// Function to determine if a tack is needed
function needToTack(currentPosition, markPosition, windDirection) {
  console.log('--- Determining Need to Tack ---');
  console.log(
    `Current Position: ${JSON.stringify(
      currentPosition,
    )}, Mark Position: ${JSON.stringify(
      markPosition,
    )}, Wind Direction: ${windDirection}`,
  );

  const headingToMark = calculateHeading(currentPosition, markPosition);
  const windAngle = Math.abs(headingToMark - windDirection);

  const needTack = windAngle < 45 || windAngle > 315;
  console.log(`Need to Tack: ${needTack}`);
  return needTack;
}

// Enhanced function to calculate an intermediate waypoint for tacking
function calculateIntermediateWaypoint(
  currentPosition,
  markPosition,
  windDirection,
) {
  console.log('--- Calculating Intermediate Waypoint ---');
  console.log(
    `Current Position: ${JSON.stringify(
      currentPosition,
    )}, Mark Position: ${JSON.stringify(
      markPosition,
    )}, Wind Direction: ${windDirection}`,
  );

  // Validate markPosition
  if (
    typeof markPosition !== 'object' ||
    typeof markPosition.latitude !== 'number' ||
    typeof markPosition.longitude !== 'number'
  ) {
    console.error('Invalid mark position data:', markPosition);
    return {latitude: null, longitude: null};
  }

  // Validate windDirection
  if (typeof windDirection !== 'number') {
    console.error('Invalid wind direction data:', windDirection);
    return {latitude: null, longitude: null};
  }

  const distanceToMark = calculateDistance(currentPosition, markPosition);
  const tackDistance = distanceToMark / 2; // Simplified to half the distance

  const tackWaypoint = {
    latitude:
      currentPosition.latitude +
      (markPosition.latitude - currentPosition.latitude) / 2,
    longitude:
      currentPosition.longitude +
      (markPosition.longitude - currentPosition.longitude) / 2,
  };

  console.log(
    `Calculated Intermediate Waypoint: ${JSON.stringify(tackWaypoint)}`,
  );
  return tackWaypoint;
}

// Example function to handle errors when formatting numbers
function safeToFixed(value, decimals = 2) {
  if (value === null || value === undefined) {
    console.error('Invalid value for formatting:', value);
    return null;
  }
  return Number(value).toFixed(decimals);
}

module.exports = {
  calculateOptimalRoute,
  calculateVMG,
  calculateHeading,
  calculateDistance,
  getSpeedFromPolars,
  needToTack,
  calculateIntermediateWaypoint,
};
