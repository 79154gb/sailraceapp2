const boatPolars = [
  {angle: 30, speed: 5},
  {angle: 60, speed: 6},
  {angle: 90, speed: 7},
  {angle: 120, speed: 6},
  {angle: 150, speed: 5},
  {angle: 180, speed: 4},
];

export default boatPolars;
